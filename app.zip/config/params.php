<?php

// INITIALISATION DES VARIABLES DYNAMIQUES
$content = "Aucun contenu";
$title = "BOOK HUNTER POO";

// PARAMÈTRES DE CONNEXION
define('DB_HOST', "localhost:8889");
define('DB_NAME', "book_hunter_2024");
define('DB_USER', "root");
define('DB_PWD', "root");
